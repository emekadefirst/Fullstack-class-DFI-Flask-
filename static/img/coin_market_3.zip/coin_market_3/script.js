const apiKey = 'ea4140e3-676e-4d43-857e-602241ec0b00'; // Replace with your actual API key

function fetchCryptoData() {
    const proxyUrl = 'https://corsproxy.io/?';
    const apiUrl = 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest';

    fetch(proxyUrl + apiUrl, {
        method: 'GET',
        headers: {
            'X-CMC_PRO_API_KEY': apiKey,
            'Accept': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => displayData(data))
    .catch(error => console.error('Error fetching data:', error));
}

function displayData(data) {
    const tableBody = document.getElementById('crypto-table-body');
    tableBody.innerHTML = '';

    data.data.forEach(crypto => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${crypto.name}</td>
            <td>${crypto.symbol}</td>
            <td>$${crypto.quote.USD.price.toFixed(2)}</td>
            <td>$${crypto.quote.USD.market_cap.toFixed(2)}</td>
        `;
        tableBody.appendChild(row);
    });
}

fetchCryptoData();
